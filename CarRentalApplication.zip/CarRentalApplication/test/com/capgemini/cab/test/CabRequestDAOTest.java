package com.capgemini.cab.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public class CabRequestDAOTest {

	static ICabRequestDAO cabRequestDao=null;
	static CabRequest cabRequest=null;
	@BeforeClass
	public static void Initialize()
	{
		cabRequestDao=new CabRequestDAO();
		cabRequest=new CabRequest();
	}
	@Test
	public void testaddCabRequestDetails1() throws CabRequestException {
		cabRequest.setCustName("John");
		cabRequest.setCustPhoneNum("9768587350");
		cabRequest.setCustAddress("Capgemini Knowledge Park, IT 1 / IT 2, TTC Industrial Area, Thane-Belapur Road, Airoli, Navi Mumbai");
		cabRequest.setCustPinCode("400708");
		cabRequest.setReqStatus("Accepted");
		cabRequest.setCabNum("MH TF 8956");
		assertEquals(1001,cabRequestDao.addCabRequestDetails(cabRequest));
	}
	@Test
	public void testaddCabRequestDetails2() throws CabRequestException {
		cabRequest.setCustName("Yaswanth");
		cabRequest.setCustPhoneNum("9700036222");
		cabRequest.setCustAddress("Capgemini Knowledge Park, IT 1 / IT 2, TTC Industrial Area, Thane-Belapur Road, Airoli, Navi Mumbai");
		cabRequest.setCustPinCode("400708");
		assertEquals(123456,cabRequestDao.addCabRequestDetails(cabRequest));
	}
	@Test
	public void testgetRequestDetails1() throws CabRequestException
	{
		Assert.assertNull(cabRequestDao.getRequestDetails(1001));
	}
	@Test
	public void testgetRequestDetails2() throws CabRequestException
	{
		Assert.assertNotNull(cabRequestDao.getRequestDetails(12345));
	}
	@Test
	public void testaddCabRequestDetails3() throws CabRequestException {
		cabRequest.setCustName("Yaswanth");
		cabRequest.setCustPhoneNum("9700036222");
		cabRequest.setCustAddress("Capgemini Knowledge Park, IT 1 / IT 2, TTC Industrial Area, Thane-Belapur Road, Airoli, Navi Mumbai");
		cabRequest.setCustPinCode("400708");
		cabRequestDao.addCabRequestDetails(cabRequest);
		Assert.assertEquals("Accepted",cabRequest.getReqStatus());
	}
	@Test
	public void testaddCabRequestDetails4() throws CabRequestException {
		cabRequest.setCustName("Yaswanth");
		cabRequest.setCustPhoneNum("9700036222");
		cabRequest.setCustAddress("Capgemini Knowledge Park, IT 1 / IT 2, TTC Industrial Area, Thane-Belapur Road, Airoli, Navi Mumbai");
		cabRequest.setCustPinCode("123456");
		cabRequestDao.addCabRequestDetails(cabRequest);
		Assert.assertEquals("Not Accepted",cabRequest.getReqStatus());
	}
}
