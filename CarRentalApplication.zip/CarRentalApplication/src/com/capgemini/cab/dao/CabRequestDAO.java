package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.cab.dao.IQueryMapper;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cab.util.*;
import com.capgemini.cabs.bean.CabRequest;

public class CabRequestDAO implements ICabRequestDAO {

	
	Logger logger=Logger.getRootLogger();
	public CabRequestDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");

	}
	/*******************************************************************************************************
	 - Function Name	:	addCabRequestDetails(CabRequest cabRequest)
	 - Input Parameters	:	CabRequest cabRequest
	 - Return Type		:	int
	 - Throws			:  	CabRequestException
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	add cab request details made by the customer
	 ********************************************************************************************************/
	
	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException{
		try {
			Connection conn=CabDBConnection.getConnection();
			java.sql.Statement statement=conn.createStatement();
			ResultSet result=statement.executeQuery(IQueryMapper.CHECKTABLE);
			result.next();
			int check=result.getInt(1);
	
			if(check<=0)
				creation();
			result=statement.executeQuery(IQueryMapper.GENERTESEQUENCE);
			result.next();
			String reqId=result.getString(1);
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERTQUERY);
			cabRequest.setReqId(reqId);
			preparedStatement.setString(1,cabRequest.getReqId());
			preparedStatement.setString(2,cabRequest.getCustName());
			preparedStatement.setString(3,cabRequest.getCustPhoneNum());
			preparedStatement.setString(4,cabRequest.getReqStatus());
			preparedStatement.setString(5,cabRequest.getCabNum());
			preparedStatement.setString(6,cabRequest.getCustAddress());
			preparedStatement.setString(7,cabRequest.getCustPinCode());
			preparedStatement.executeUpdate();
			logger.info("Data Inserted Successfully");
			try{
				result.close();
			preparedStatement.close();
			conn.close();
			return Integer.parseInt(reqId);
			}
			catch(SQLException e)
			{
				logger.error(e.getMessage());
				throw new CabRequestException("Error in closing connection");		
			}
			
		} catch (SQLException e) {
			throw new CabRequestException("DB Connection Problem");
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:	creatiob()
	 - Input Parameters	:	
	 - Return Type		:	void
	 - Throws			:  	CabRequestException
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	creates cab_request table and seq_request_id sequence in database
	 ********************************************************************************************************/

	private void creation() throws CabRequestException {
		
		try {
			Connection conn = CabDBConnection.getConnection();		
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.CREATETABLE);
			preparedStatement.execute();
			logger.info("Table Created Successfully");
			preparedStatement=conn.prepareStatement(IQueryMapper.SEQUENCECREATION);
			preparedStatement.execute();
			logger.info("Sequence Created Successfully");
		}
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CabRequestException("Error in table creation");

			}
	}
	/*******************************************************************************************************
	 - Function Name	:	getRequestDetails(int requestId)
	 - Input Parameters	:	int requestId
	 - Return Type		:	CabRequest
	 - Throws			:  	CabRequestException
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	retrieves customer details from database based on requestId
	 ********************************************************************************************************/
	@Override
	public CabRequest getRequestDetails(int requestId) throws CabRequestException{
		try {
			Connection conn = CabDBConnection.getConnection();
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.CHECKREQID);
		preparedStatement.setInt(1,requestId);
		ResultSet result=preparedStatement.executeQuery();
		result.next();
		int count=result.getInt(1);
		CabRequest cabRequest=null;
		if(count<=0)
		{
			logger.error("Request Id is invalid");
			throw new CabRequestException("Invalid request Id");
		}
		else
		{
			preparedStatement=conn.prepareStatement(IQueryMapper.GETDETAILS);
			preparedStatement.setInt(1,requestId);
			result=preparedStatement.executeQuery();
			cabRequest=new CabRequest();
			while(result.next())
			{
				cabRequest.setCustName(result.getString(1));
				cabRequest.setReqStatus(result.getString(2));
				cabRequest.setCabNum(result.getString(3));
			}
		}	
		try{
			preparedStatement.close();
			result.close();
			conn.close();
			logger.info("Details Retrieved Successfully");
			return cabRequest;
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			throw new CabRequestException("Error in retrieving details");	
		}
			
			}
			
		catch (SQLException e) 
		{
			logger.error(e.getMessage());
			throw new CabRequestException("Error in retrieving details");

		}
	}

	

}
