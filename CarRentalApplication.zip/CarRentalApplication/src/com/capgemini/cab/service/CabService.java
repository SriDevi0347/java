
package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;


public class CabService implements ICabService{
	/*******************************************************************************************************
	 - Function Name	:	addCabRequestDetails(CabRequest cabRequest)
	 - Input Parameters	:	CabRequest cabRequest
	 - Return Type		:	int
	 - Throws			:  	CabRequestException
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	add cab request details made by the customer by calling addCabRequestDetails(CabRequest cabRequest) method in DAO
	 ********************************************************************************************************/
	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException {
		ICabRequestDAO cabRequestDao=new CabRequestDAO();
		return cabRequestDao.addCabRequestDetails(cabRequest);
	}
	/*******************************************************************************************************
	 - Function Name	:	getRequestDetails(int requestId)
	 - Input Parameters	:	int requestId
	 - Return Type		:	CabRequest
	 - Throws			:  	CabRequestException
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	retrieves customer details from dao based on requestId by calling getRequestDetails(requestId) method in DAO
	 ********************************************************************************************************/
	@Override
	public CabRequest getRequestDetails(int requestId) throws CabRequestException {
		ICabRequestDAO cabRequestDao=new CabRequestDAO();
		return cabRequestDao.getRequestDetails(requestId);
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidName(String custName)
	 - Input Parameters	:	String custName
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	validates customername
	 ********************************************************************************************************/
	@Override
	public boolean isValidName(String custName) {
		Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{3,}");
		Matcher m=p.matcher(custName);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Name is Invalid. It should start with Capital letter and should be minimum 3 characters");
			return false;
		}
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidNumber(String phoneNo)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	validates phonenumber
	 ********************************************************************************************************/
	@Override
	public boolean isValidNumber(String phoneNo) {
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(phoneNo);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Invalid Phone Number");
			return false;
		}
	}

	/*******************************************************************************************************
	 - Function Name	:	isValidAddress(String address)
	 - Input Parameters	:	String address
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	validates customer address
	  ********************************************************************************************************/
	@Override
	public boolean isValidAddress(String address) {
		Pattern p=Pattern.compile("[A-Z].*{3,}");
		Matcher m=p.matcher(address);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Address is Invalid. It should start with Capital letter and should be minimum 3 characters");
			return false;
		}
	}
	/*******************************************************************************************************
	 - Function Name	:	getCarNumber(String pincode)
	 - Input Parameters	:	String pincode
	 - Return Type		:	String
	 - Throws			:   
	 - Author			:	yaswanth
	 - Creation Date	:	20/06/2018
	 - Description		:	validates pincode and returning Cab Number
	 ********************************************************************************************************/

	@Override
	public String getCarNumber(String pincode) {
		if(pincode.equals("400096"))
		{
			return "MH VS 2345";
		}
		else if(pincode.equals("411026"))
		{
			return "MH VH 34567";
		}
		else if(pincode.equals("411013"))
		{
			return "MH AN 97886";
		}
		else if(pincode.equals("560066"))
		{
			return "MH AS 875";
		}
		else if(pincode.equals("382009"))
		{
			return "MH KN 9856";
		}
		else if(pincode.equals("400708"))
		{
			return "MH TF 8956";
		}
		else 
			return null;
	}
}
