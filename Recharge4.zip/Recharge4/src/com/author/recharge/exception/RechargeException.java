package com.author.recharge.exception;

public class RechargeException extends Exception{
	private String exceptionName;
	public RechargeException(String exceptionName)
	{
		this.exceptionName=exceptionName;
	}
	public String toString()
	{
		return this.exceptionName;
	}
}
