package com.author.recharge.dao;

import java.sql.SQLException;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.RechargeException;

public interface IRechargeDao {
	StringBuilder displayPlans() throws SQLException, RechargeException;
	StringBuilder retrieveUserDetails(int rechId) throws SQLException, RechargeException;
	int retrieveAmount(String plan) throws SQLException, RechargeException;
	boolean validPlan(String planName) throws SQLException, RechargeException;
	boolean validRechId(int rechId) throws SQLException, RechargeException;
	int addUserDetails(RechargeBean b) throws SQLException, RechargeException;
}