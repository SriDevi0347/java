package com.author.recharge.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.RechargeException;
import com.author.recharge.util.DBConnection;

public class RechargeDaoImpl implements IRechargeDao{
	Logger logger=Logger.getRootLogger();
	public RechargeDaoImpl()
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		
	}
	@Override
	public StringBuilder displayPlans() throws RechargeException, SQLException {
		Connection conn=DBConnection.getInstance().getConnection();
		StringBuilder s2=new StringBuilder("");
		java.sql.Statement s=conn.createStatement();
		
			ResultSet r=s.executeQuery(IQueryMapper.selectPlans);
			if(r.next())
			{
				logger.info("details displayed sucessfully");
				s2.append("plans      amount\n");
				s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				while(r.next())
				{
					s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				}
			}
			else
			{
				logger.error("error while fetching plan details");
			}
			return s2;
	}

	@Override
	public int addUserDetails(RechargeBean b) throws SQLException, RechargeException {
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s=conn.prepareStatement(IQueryMapper.insertQuery);
		java.sql.Statement sw=conn.createStatement();
		ResultSet r1=sw.executeQuery(IQueryMapper.seqQuery);
		int val=0;
		while(r1.next())
		{
			val=r1.getInt(1);
		}
		s.setInt(1,val);
		s.setString(2,b.getUserName());
		s.setLong(3,b.getUserMobileNum());
		s.setString(4,b.getStatus());
		s.setString(5,b.getPlanName());
		s.setInt(6,b.getAmount());
		int val1=s.executeUpdate();
		if(val1==1)
		{
			logger.info("user details added sucessfully");
		}
		else
		{
			logger.error("error while adding user details");
		}
		return val;
	}
	@Override
	public StringBuilder retrieveUserDetails(int rechId) throws SQLException, RechargeException {
		
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s=conn.prepareStatement(IQueryMapper.userDetailsQuery);
		StringBuilder s2=new StringBuilder("");
		s.setInt(1, rechId);
		ResultSet r=s.executeQuery();
			if(r.next())
			{
				s2.append("rech id"+r.getInt(1)+"\nname:"+r.getString(2)+"\nmobile:"+r.getLong(3)+"\nstatus:"+r.getString(4)
					+"\nplan name:"+r.getString(5)+"\namount:"+r.getInt(6));
				logger.info("details retrieved sucessfully");
			}
			else
			{
				logger.error("error while displaying details");
				throw new RechargeException("please enter valid recharge ID");
			}
			return s2;
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException, RechargeException {
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s=conn.prepareStatement(IQueryMapper.retrieveAmountQuery);
		s.setString(1,plan);
		int amount=0;
		ResultSet r=s.executeQuery();
		while(r.next())
		{
			amount=r.getInt(1);
		}
		return amount;
	}

	@Override
	public boolean validPlan(String planName) throws SQLException, RechargeException {
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s=conn.prepareStatement(IQueryMapper.validPlanQuery);
		s.setString(1,planName);
		ResultSet r=s.executeQuery();
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			logger.error("planname not available");
			throw new RechargeException("planname entered is not available");
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean validRechId(int rechId) throws SQLException, RechargeException {
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s=conn.prepareStatement(IQueryMapper.validRechIdQuery);
		s.setInt(1, rechId);
		ResultSet r=s.executeQuery();
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			logger.error("recharge ID is not available");
			throw new RechargeException("recharge ID entered is not available");
		}
		else
		{
			return true;
		}
	}
}