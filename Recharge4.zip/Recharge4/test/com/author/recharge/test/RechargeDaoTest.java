package com.author.recharge.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.*;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.dao.RechargeDaoImpl;
import com.author.recharge.exception.RechargeException;

public class RechargeDaoTest {
	static RechargeDaoImpl d;
	static RechargeBean b;
	
	@BeforeClass
	public static void initialize()
	{
		d=new RechargeDaoImpl();
		b=new RechargeBean();
	}
		
	@Test
	public void testRetrieveDetails() throws SQLException, RechargeException
	{
		assertNotNull(d.retrieveUserDetails(10000));
	}
	
	@Test
	public void testAddUserDetails() throws SQLException, RechargeException
	{
		b.setAmount(500);
		b.setPlanName("Rc500");
		b.setStatus("recharge sucessfull");
		b.setUserEmailId("saranu.trini@gmail.com");
		b.setUserMobileNum(7659840158L);
		b.setUserName("TriniSai");
		assertEquals(10086,d.addUserDetails(b));
	}
	
	@Test
	public void testDisplayPlans() throws RechargeException, SQLException
	{
		assertNotNull(d.displayPlans());
	}
	
	@Test
	public void testRetrieveAmount()
	{
		try {
			assertEquals(99,d.retrieveAmount("Rc99"));
		} catch (SQLException | RechargeException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testValidPlan()
	{
		try {
			assertTrue(d.validPlan("Rc99"));
		} catch (SQLException | RechargeException e) {
			System.out.println(e.getMessage());
		}
	}
}
