package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.dao.ILMSDao;
import com.cg.plp.dao.LMSDaoImpl;
import com.cg.plp.exception.LibraryException;

public class LibrarianServiceImpl implements ILibrarianService 
{
	ILMSDao lmsDao=new LMSDaoImpl(); 
	
	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException
	{
		return lmsDao.addBooks(bookBean);
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		return lmsDao.removeBook(bookId);
	}

	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException 
	{
		return lmsDao.showBooks();
	}
	
	@Override
	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException
	{
		return lmsDao.showRegisteredBooks();
	}

	@Override
	public String grantBook(String registrationId, String bookId) throws LibraryException 
	{
		return lmsDao.grantBook(registrationId,bookId);
	}
}
