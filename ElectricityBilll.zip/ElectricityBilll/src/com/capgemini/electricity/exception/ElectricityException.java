package com.capgemini.electricity.exception;

public class ElectricityException extends Exception{
	String msg;
	public ElectricityException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
