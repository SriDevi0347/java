package com.capgemini.electricity.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.electricity.bean.ElectricityBean;
import com.capgemini.electricity.bean.ElectricityBillBean;
import com.capgemini.electricity.bean.ElectricityConsumerBean;

public class ElectricityDaoImpl implements IElectricityDao{

	@Override
	public void addDetails(ElectricityBean bean)  {
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement st=con.prepareStatement("insert into BillDetails values(seq_bill_num.nextval,?,?,?,?,sysdate)");
			st.setInt(1, bean.getConsumerNum());
			st.setFloat(2, bean.getCurrReading());
			st.setFloat(3, bean.getUnitsConsumed());
			st.setFloat(4, bean.getNetAmount());
			st.executeUpdate();
		} 
		catch (SQLException e) {
		System.out.println(e.getMessage());
		} 
		catch (NamingException e) 
		{
			System.out.println(e.getMessage());
		}
	}

	@Override
	public boolean isValidConsumer(int consumerNumber) {
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement st=con.prepareStatement("select count(*) from consumers where consumer_num=?");
			st.setInt(1,consumerNumber);
			ResultSet re=st.executeQuery();
			re.next();
			int count=re.getInt(1);
			if(count>0)
			{
				return true;
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e)
		{
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public String getConsumerName(int consumerNumber) {
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement st=con.prepareStatement("select consumer_name from consumers where consumer_num=?");
			st.setInt(1, consumerNumber);
			ResultSet re=st.executeQuery();
			re.next();
			return re.getString(1);
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public ArrayList<ElectricityConsumerBean> getList() {
		ArrayList<ElectricityConsumerBean> li=null;
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			li=new ArrayList<>();
			PreparedStatement s=con.prepareStatement("select * from consumers");
			ResultSet se=s.executeQuery();
			while(se.next())
			{
				ElectricityConsumerBean bean=new ElectricityConsumerBean();
				bean.setConsumerNumber(se.getInt(1));
				bean.setConsumerName(se.getString(2));
				bean.setConsumerAddress(se.getString(3));
				li.add(bean);
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e)
		{
			System.out.println(e.getMessage());
		}
		return li;
	}

	@Override
	public ElectricityConsumerBean getConsumerDetails(int consumernumber) {
		ElectricityConsumerBean bean=null;
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement s=con.prepareStatement("select * from consumers where consumer_num=?");
			s.setInt(1, consumernumber);
			ResultSet rt=s.executeQuery();
			bean=new ElectricityConsumerBean();
			if(rt.next())
			{
				bean.setConsumerNumber(rt.getInt(1));
				bean.setConsumerName(rt.getString(2));
				bean.setConsumerAddress(rt.getString(3));
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e)
		{
			System.out.println(e.getMessage());
		}
		return bean;
	}

	@Override
	public ArrayList<ElectricityBillBean> getBills(int num) {
		ArrayList<ElectricityBillBean> li=null;
		try 
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			li=new ArrayList<>();
			PreparedStatement s=con.prepareStatement("select * from billdetails where consumer_num=?");
			s.setInt(1, num);
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				ElectricityBillBean bean=new ElectricityBillBean();
				bean.setBillNum(st.getInt(1));
				bean.setConsumerNum(st.getInt(2));
				bean.setCurrReading(st.getFloat(3));
				bean.setUnitCons(st.getFloat(4));
				bean.setNetAmount(st.getFloat(5));
				bean.setBillMonth(st.getDate(6));
				li.add(bean);
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e)
		{
			System.out.println(e.getMessage());
		}
		return li;
	}

	
}
