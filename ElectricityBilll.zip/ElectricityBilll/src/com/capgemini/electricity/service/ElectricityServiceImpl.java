package com.capgemini.electricity.service;

import java.util.ArrayList;

import com.capgemini.electricity.bean.ElectricityBean;
import com.capgemini.electricity.bean.ElectricityBillBean;
import com.capgemini.electricity.bean.ElectricityConsumerBean;
import com.capgemini.electricity.dao.ElectricityDaoImpl;
import com.capgemini.electricity.dao.IElectricityDao;

public class ElectricityServiceImpl implements IElectricityService{

	@Override
	public void addDetails(ElectricityBean bean) {
		IElectricityDao dao=new ElectricityDaoImpl();
		dao.addDetails(bean);
	}

	@Override
	public boolean isValidConsumer(int consumerNumber) {
		IElectricityDao dao=new ElectricityDaoImpl();
		return dao.isValidConsumer(consumerNumber);
	}

	@Override
	public String getConsumerName(int consumerNumber) {
		IElectricityDao dao=new ElectricityDaoImpl();
		return dao.getConsumerName(consumerNumber);
	}

	@Override
	public ArrayList<ElectricityConsumerBean> getList() {
		IElectricityDao dao=new ElectricityDaoImpl();
		return dao.getList();
	}

	@Override
	public ElectricityConsumerBean getConsumerDetails(int consumernumber) {
		IElectricityDao dao=new ElectricityDaoImpl();
		return dao.getConsumerDetails(consumernumber);
	}

	@Override
	public ArrayList<ElectricityBillBean> getBills(int num) {
		IElectricityDao dao=new ElectricityDaoImpl();
		return dao.getBills(num);
	}
}
