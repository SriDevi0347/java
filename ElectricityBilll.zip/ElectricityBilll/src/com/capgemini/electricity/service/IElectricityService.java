package com.capgemini.electricity.service;

import java.util.ArrayList;

import com.capgemini.electricity.bean.ElectricityBean;
import com.capgemini.electricity.bean.ElectricityBillBean;
import com.capgemini.electricity.bean.ElectricityConsumerBean;

public interface IElectricityService {

	void addDetails(ElectricityBean bean);

	boolean isValidConsumer(int consumerNumber);

	String getConsumerName(int consumerNumber);

	ArrayList<ElectricityConsumerBean> getList();

	ElectricityConsumerBean getConsumerDetails(int consumernumber);

	ArrayList<ElectricityBillBean> getBills(int num);

	
}
