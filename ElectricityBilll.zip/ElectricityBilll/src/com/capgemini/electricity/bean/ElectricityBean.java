package com.capgemini.electricity.bean;

public class ElectricityBean {
	private int consumerNum;
	private float lastReading;
	private float currReading;
	private float unitsConsumed;
	private float netAmount;
	private int billNum;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public float getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(float unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public float getLastReading() {
		return lastReading;
	}
	public void setLastReading(float lastReading) {
		this.lastReading = lastReading;
	}
	public float getCurrReading() {
		return currReading;
	}
	public void setCurrReading(float currReading) {
		this.currReading = currReading;
	}
	
}
