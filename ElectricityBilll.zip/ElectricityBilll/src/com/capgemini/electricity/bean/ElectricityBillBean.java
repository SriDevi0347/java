package com.capgemini.electricity.bean;

import java.sql.Date;

public class ElectricityBillBean {
	private int billNum;
	private Date billMonth;
	private int consumerNum;
	private float currReading;
	private float unitCons;
	private float netAmount;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public Date getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(Date billMonth) {
		this.billMonth = billMonth;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public float getCurrReading() {
		return currReading;
	}
	public void setCurrReading(float currReading) {
		this.currReading = currReading;
	}
	public float getUnitCons() {
		return unitCons;
	}
	public void setUnitCons(float unitCons) {
		this.unitCons = unitCons;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
}
