package com.capgemini.electricity.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.electricity.bean.ElectricityBean;
import com.capgemini.electricity.bean.ElectricityBillBean;
import com.capgemini.electricity.bean.ElectricityConsumerBean;
import com.capgemini.electricity.exception.ElectricityException;
import com.capgemini.electricity.service.ElectricityServiceImpl;
import com.capgemini.electricity.service.IElectricityService;

/**
 * Servlet implementation class ElectricityController
 * @param <E>
 */
@WebServlet("/ElectricityController")
public class ElectricityController<E> extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ElectricityController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		int consumerNumber;
		IElectricityService ser=new ElectricityServiceImpl();
		if(operation.equals("login"))
		{
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			if(username.equals("admin") && password.equals("admin"))
			{
				RequestDispatcher re=getServletContext().getRequestDispatcher("/details.html");
				re.forward(request, response);
			}
		}
		
		if(operation.equals("details"))
		{
				String num=request.getParameter("conNum");
				consumerNumber=Integer.parseInt(num);
				if(ser.isValidConsumer(consumerNumber))
				{
					String last=request.getParameter("lastReading");
					String curr=request.getParameter("currReading");
					float lastReading=Float.parseFloat(last);
					float currReading=Float.parseFloat(curr);
					if(currReading<lastReading)
					{
						RequestDispatcher re=getServletContext().getRequestDispatcher("/details.html");
						re.include(request, response);
						write.println("<center>current month reading should be greater than last month reading</center>");
					}
					else
					{
						float unitsConsumed=currReading-lastReading;
						float netAmount=(float) ((unitsConsumed*1.15)+100);
						netAmount=Math.round(netAmount*100)/100;
						ElectricityBean bean=new ElectricityBean();
						bean.setConsumerNum(consumerNumber);
						bean.setCurrReading(currReading);
						bean.setLastReading(lastReading);
						bean.setUnitsConsumed(unitsConsumed);
						bean.setNetAmount(netAmount);
						ser.addDetails(bean);
						String name;
						name=ser.getConsumerName(consumerNumber);
						request.setAttribute("bean", bean);
						request.setAttribute("name", name);
						RequestDispatcher rd=request.getRequestDispatcher("/BillInfo.jsp");
						rd.forward(request, response);
					}
				}
				else
				{
					request.setAttribute("error",  new ElectricityException("error occured:<br>No bill details found for customer number:"
							+consumerNumber ));
					RequestDispatcher rd=request.getRequestDispatcher("/Error.jsp");
					rd.forward(request, response);
				}
		}
		if(operation.equals("list"))
		{
			ArrayList<ElectricityConsumerBean> bean=ser.getList();
			request.setAttribute("bean", bean);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_ConsumerList.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("search"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/SearchConsumer.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("search1"))
		{
			String x=request.getParameter("consNum");
			int consumernumber=Integer.parseInt(x);
			if(ser.isValidConsumer(consumernumber))
			{
				ElectricityConsumerBean b=ser.getConsumerDetails(consumernumber);
				request.setAttribute("condetails", b);
				RequestDispatcher rd=request.getRequestDispatcher("/ShowConsumer.jsp");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("/SearchConsumer.jsp");
				rd.include(request, response);
				write.println("enter valid consumer number");
			}
		}
		if(operation.equals("complete"))
		{
			String n=request.getParameter("num");
			int num=Integer.parseInt(n);
			ArrayList<ElectricityBillBean> b=ser.getBills(num);
			request.setAttribute("bean", b);
			RequestDispatcher rd=request.getRequestDispatcher("/showBills.jsp");
			rd.forward(request, response);
		}
	}

}
